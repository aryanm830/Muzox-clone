module.exports.run = async (client, info) => {
  console.log(info)
}