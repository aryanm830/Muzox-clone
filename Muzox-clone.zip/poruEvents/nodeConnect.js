module.exports.run = async (client,node) => {
client.logger.log(`Node ${node.name} is ready!`)
}