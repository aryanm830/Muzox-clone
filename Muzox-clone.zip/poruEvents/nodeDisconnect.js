module.exports.run = async (client,node) => {
client.logger.log(`Node ${node.name} got disconnected!`)
}