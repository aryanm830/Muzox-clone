const { EmbedBuilder } = require('discord.js')

module.exports.run = async (client, player, message) => {
  
player.message?.delete().catch(e => null) 
}
